<?php

require_once('../../config.php');

//$courseid = required_param('id', PARAM_INT);


//Accesss Control checks.

$context = context_system::instance();
//require_capability('local/courseschedule:coursesched', $context);
require_login();

//set up a moodle page
$PAGE->set_url(new moodle_url('/local/courseschedule/coursesched.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Manage Course Schedule');

//call table from the database
$notifications = $DB->get_records('local_courseschedule');

echo $OUTPUT->header();
$templatecontext = (object)[
    'notifications' => array_values($notifications),
    'editurl' => new moodle_url('/local/courseschedule/edit.php'),
    'deleteurl' => new moodle_url('/local/courseschedule/delete.php'),
];
echo $OUTPUT->render_from_template('local_courseschedule/coursesched', $templatecontext);
echo $OUTPUT->footer();


?>