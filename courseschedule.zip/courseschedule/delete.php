<?php


require_once(__DIR__ . '/../../config.php');

global $DB;

$PAGE->set_url(new moodle_url('/local/courseschedule/delete.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Delete Schedule');

$context = context_system::instance();

if (has_capability('local/courseschedule:delete', $context)) {
  $DB->delete_records('local_courseschedule', array('id' => htmlspecialchars($_GET['id'])));
  redirect($CFG->wwwroot . '/local/courseschedule/courseschedule.php', 'Schedule Deleted');
} else {
  redirect($CFG->wwwroot . '/', 'You do not have permission to access this resource');
}

?>