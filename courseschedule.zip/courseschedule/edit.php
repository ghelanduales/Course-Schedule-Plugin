<?php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/local/courseschedule/classes/form/edit.php');

global $DB;

$PAGE->set_url(new moodle_url('/local/courseschedule/edit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Edit Schedule');

$context = context_system::instance();

//if (has_capability('local/courseschedule:create', $context)) {
$mform = new edit();
if ($mform->is_cancelled()) {
    redirect($CFG->wwwroot . '/local/courseschedule/coursesched.php', 'You cancelled');
} else if ($fromform = $mform->get_data()) {
    $notifications = new stdClass();
    $notifications->sched_code = $fromform->sched_code;
    $notifications->course_code = $fromform->course_code;
    $notifications->course_description = $fromform->course_description;
    $notifications->unit = $fromform->unit;
    $notifications->time = $fromform->time;
    $notifications->day = $fromform->day;
    $notifications->room = $fromform->room;

    $DB->insert_record('local_courseschedule', $notifications);
    redirect($CFG->wwwroot . '/local/courseschedule/courseched.php', 'Schedule created: ' . $fromform->sched_code);
}
echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
//} else {
  //redirect($CFG->wwwroot . '/', 'You do not have permission to access this resource');
?>