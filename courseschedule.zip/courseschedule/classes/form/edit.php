<?php

require_once("$CFG->libdir/formslib.php");

class edit extends moodleform
{
    public function definition()
    {
        global $CFG;

        $mform = $this->_form;

        //schedule code
        $mform->addElement('int', 'sched_code', 'sched code');
        $mform->setType('sched_code', PARAM_NOTAGS);
        $mform->setDefault('sched_code', 'Enter course schedule here...');


        //course code
        $mform->addElement('text', 'course_code', 'course code');
        $mform->setType('course_code', PARAM_NOTAGS);
        $mform->setDefault('course_code', 'Enter course code here...');


        //course description
        $mform->addElement('text', 'course_description', 'course description');
        $mform->setType('course_description', PARAM_NOTAGS);
        $mform->setDefault('course_description', 'Enter course description here...');

        //unit
        $mform->addElement('int', 'unit', 'unit');
        $mform->setType('unit', PARAM_NOTAGS);
        $mform->setDefault('unit', 'Enter unit/s here...');

        //time
        $mform->addElement('text', 'time', 'time');
        $mform->setType('time', PARAM_NOTAGS);
        $mform->setDefault('time', 'Enter time here...');

        //day
        $mform->addElement('text', 'day', 'day');
        $mform->setType('day', PARAM_NOTAGS);
        $mform->setDefault('day', 'Enter day here...');
        
        //room
        $mform->addElement('text', 'room', 'room');
        $mform->setType('room', PARAM_NOTAGS);
        $mform->setDefault('room', 'Enter room here...');

        $this->add_action_buttons();
    }

    function validation($data, $files)
    {
        return array();
    }
}

?>